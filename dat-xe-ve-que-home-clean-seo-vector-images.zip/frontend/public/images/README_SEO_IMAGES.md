# SEO images

Bộ ảnh này là minh họa/vector sạch, không dùng ảnh AI người/xe méo.

Quy tắc:
- Tên file có keyword tuyến: `xe-sai-gon-di-duc-linh.webp`.
- Dùng `.webp` trước, `.jpg` fallback nếu cần.
- Alt text phải mô tả tuyến và dịch vụ, không nhồi keyword.
- Hero dùng preload trong `frontend/index.html` và `HomePage.tsx`.
