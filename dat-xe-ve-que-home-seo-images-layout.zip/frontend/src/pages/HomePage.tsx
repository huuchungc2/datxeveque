import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  Box,
  CalendarCheck2,
  Car,
  CheckCircle2,
  ClipboardCheck,
  MapPinned,
  PhoneCall,
  Search,
  ShieldCheck,
  ShoppingBasket,
  Star,
  Users,
} from "lucide-react";

import { coreBookableServices } from "../routes/bookableServices";

const HERO_IMAGE = "/images/hero-dat-xe-ve-que-sai-gon-duc-linh.webp";

const serviceIcons: Record<string, typeof Car> = {
  SHARED_RIDE: Car,
  PRIVATE_RIDE: Car,
  CARGO: Box,
  MARKET: ShoppingBasket,
  CONTRACT: Users,
};

const serviceDesc: Record<string, string> = {
  SHARED_RIDE: "Gom khách theo tuyến, giá theo người",
  PRIVATE_RIDE: "Xe riêng 4–7–16 chỗ, giá theo chuyến",
  CARGO: "Nhận hàng 2 chiều, giao tận nơi",
  MARKET: "Mua đồ quê, đóng gói, gửi lên phố",
  CONTRACT: "Theo lịch trình, báo giá riêng",
};

const services = coreBookableServices.map((s) => ({
  title: s.menuLabel,
  desc: serviceDesc[s.type] || s.title,
  icon: serviceIcons[s.type] || Car,
  href: s.path,
}));

const routeHighlights = [
  {
    title: "Sài Gòn → Đức Linh",
    subtitle: "Xe ghép / bao xe / gửi hàng",
    href: "/xe-sai-gon-di-duc-linh",
    image: "/images/xe-sai-gon-di-duc-linh.webp",
    alt: "Xe Sài Gòn đi Đức Linh dương lịch, đặt xe về quê",
  },
  {
    title: "Sài Gòn → Tánh Linh",
    subtitle: "Đặt lịch trước, có xác nhận",
    href: "/xe-sai-gon-di-tanh-linh",
    image: "/images/xe-sai-gon-di-tanh-linh.webp",
    alt: "Xe Sài Gòn đi Tánh Linh, tuyến về quê Bình Thuận",
  },
  {
    title: "Đức Linh → Sài Gòn",
    subtitle: "Chuyến chiều về trong ngày",
    href: "/xe-duc-linh-di-sai-gon",
    image: "/images/xe-duc-linh-di-sai-gon.webp",
    alt: "Xe Đức Linh đi Sài Gòn, xe ghép và bao xe",
  },
  {
    title: "Lagi → Sài Gòn",
    subtitle: "Ven biển, xe riêng, xe ghép",
    href: "/dat-xe",
    image: "/images/xe-lagi-di-sai-gon.webp",
    alt: "Xe Lagi đi Sài Gòn, đặt xe về quê ven biển",
  },
];

function MiniBookingCard() {
  return (
    <div className="rounded-[2rem] border border-white/80 bg-white/95 p-5 shadow-2xl backdrop-blur-xl">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <p className="text-xs font-extrabold uppercase tracking-[0.22em] text-brand-700">Tìm chuyến xe</p>
          <h2 className="mt-1 text-xl font-extrabold text-ink-900">Đặt nhanh trong 30 giây</h2>
        </div>
        <CalendarCheck2 className="text-brand-700" size={30} />
      </div>

      <div className="grid gap-3">
        <label className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
          <span className="block text-xs font-bold text-slate-500">Tuyến đường</span>
          <b>Sài Gòn → Đức Linh</b>
        </label>
        <div className="grid grid-cols-2 gap-3">
          <label className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
            <span className="block text-xs font-bold text-slate-500">Ngày đi</span>
            <b>26/05/2026</b>
          </label>
          <label className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
            <span className="block text-xs font-bold text-slate-500">Giờ đi</span>
            <b>06:00</b>
          </label>
        </div>
        <div className="rounded-2xl border border-brand-100 bg-brand-50 px-4 py-3">
          <span className="block text-xs font-bold text-brand-700">Giá tạm tính</span>
          <b className="text-2xl text-cta-500">360.000đ</b>
        </div>
        <Link className="btn-primary w-full" to="/dat-xe">
          <Search size={18} /> Tìm chuyến & xem giá
        </Link>
      </div>
    </div>
  );
}

function ImageRouteCard({ route }: { route: (typeof routeHighlights)[number] }) {
  return (
    <Link
      to={route.href}
      className="group overflow-hidden rounded-[1.75rem] border border-slate-200 bg-white shadow-card transition hover:-translate-y-1 hover:border-brand-200 hover:shadow-soft"
    >
      <div className="relative h-32 overflow-hidden">
        <img
          src={route.image}
          alt={route.alt}
          loading="lazy"
          width="640"
          height="360"
          className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/55 via-transparent to-transparent" />
        <span className="absolute bottom-3 left-3 inline-flex items-center gap-1 rounded-full bg-white/90 px-3 py-1 text-xs font-extrabold text-brand-700 backdrop-blur">
          <MapPinned size={13} /> Tuyến nổi bật
        </span>
      </div>
      <div className="flex items-center justify-between gap-3 p-4">
        <span>
          <b className="block text-ink-900">{route.title}</b>
          <span className="text-sm text-ink-500">{route.subtitle}</span>
        </span>
        <ArrowRight className="text-slate-400 transition group-hover:translate-x-1 group-hover:text-brand-700" size={19} />
      </div>
    </Link>
  );
}

export default function HomePage() {
  return (
    <>
      <Helmet>
        <title>Đặt Xe Về Quê | Xe Sài Gòn đi Đức Linh, Tánh Linh</title>
        <meta
          name="description"
          content="Đặt xe Sài Gòn đi Đức Linh, Tánh Linh. Xe ghép, bao xe, gửi hàng, đi chợ quê, thuê xe hợp đồng. Hiển thị dương lịch Việt Nam dd/MM/yyyy."
        />
        <meta property="og:title" content="Đặt Xe Về Quê | Xe Sài Gòn đi Đức Linh, Tánh Linh" />
        <meta property="og:description" content="Đặt xe về quê, xe ghép, bao xe, gửi hàng, đi chợ quê. Giá minh bạch, có tài xế xác nhận." />
        <meta property="og:image" content="/images/og-dat-xe-ve-que-sai-gon-duc-linh.webp" />
        <meta property="og:image:alt" content="Đặt xe về quê tuyến Sài Gòn Đức Linh Tánh Linh" />
        <meta name="twitter:image" content="/images/og-dat-xe-ve-que-sai-gon-duc-linh.webp" />
        <link rel="preload" as="image" href={HERO_IMAGE} />
      </Helmet>

      <section className="relative overflow-hidden bg-[#f7fffd]">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_12%_10%,rgba(20,184,166,.18),transparent_28%),radial-gradient(circle_at_88%_18%,rgba(249,115,22,.13),transparent_24%)]" />
        <div className="page relative grid gap-7 py-8 md:grid-cols-[1.05fr_.95fr] md:items-stretch md:py-12 lg:py-16">
          <div className="relative overflow-hidden rounded-[2.5rem] border border-white bg-white shadow-soft">
            <img
              src={HERO_IMAGE}
              alt="Đặt xe về quê tuyến Sài Gòn đi Đức Linh Tánh Linh bằng xe ghép và bao xe"
              width="1600"
              height="1000"
              fetchPriority="high"
              className="absolute inset-0 h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-white via-white/88 to-white/18" />
            <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-white via-white/65 to-transparent" />

            <div className="relative z-10 flex min-h-[38rem] flex-col justify-between p-6 md:p-9 lg:p-10">
              <div className="max-w-2xl">
                <span className="inline-flex items-center gap-2 rounded-full border border-brand-100 bg-white/85 px-4 py-2 text-xs font-extrabold uppercase tracking-[0.22em] text-brand-700 shadow-card backdrop-blur">
                  <ShieldCheck size={15} /> Đặt Xe Về Quê
                </span>
                <h1 className="mt-5 max-w-[13ch] text-balance text-4xl font-extrabold leading-[1.05] tracking-tight text-ink-900 md:text-5xl lg:text-6xl">
                  Đặt xe về quê nhanh chóng
                </h1>
                <p className="mt-5 max-w-lg text-base leading-8 text-slate-700 md:text-lg">
                  Xe ghép, bao xe, gửi hàng, đi chợ quê và thuê xe hợp đồng tuyến Sài Gòn ⇄ Đức Linh, Tánh Linh. Rõ giá, đúng lịch dương Việt Nam, có tài xế xác nhận.
                </p>
                <div className="mt-7 flex flex-col gap-3 sm:flex-row">
                  <Link className="btn-primary" to="/dat-xe">
                    Đặt xe ngay <ArrowRight size={18} />
                  </Link>
                  <Link className="btn-ghost bg-white/85" to="/lien-he">
                    <PhoneCall size={18} /> Liên hệ tư vấn
                  </Link>
                </div>
              </div>

              <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                {[
                  ["Có tài xế xác nhận", "Không đặt xong rồi bỏ lửng"],
                  ["Giá minh bạch", "Hiện giá tạm tính trước"],
                  ["Dương lịch dd/MM", "Không lỗi năm 2569 BE"],
                  ["Hỗ trợ tận tâm", "Gọi/Zalo khi cần"],
                ].map(([title, desc], i) => (
                  <div key={title} className="rounded-2xl border border-white/80 bg-white/85 p-4 shadow-card backdrop-blur">
                    <div className="mb-2 grid h-9 w-9 place-items-center rounded-xl bg-brand-50 text-brand-700">
                      {i + 1}
                    </div>
                    <b className="text-sm text-ink-900">{title}</b>
                    <p className="mt-1 text-xs leading-5 text-slate-500">{desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="grid gap-5 self-stretch md:grid-rows-[auto_1fr]">
            <MiniBookingCard />
            <div className="rounded-[2rem] border border-slate-200 bg-white p-5 shadow-card">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-xs font-extrabold uppercase tracking-[0.22em] text-brand-700">Tuyến nổi bật</p>
                  <h2 className="mt-1 text-2xl font-extrabold">Chọn tuyến để đặt ngay</h2>
                </div>
                <Star className="text-cta-500" size={38} />
              </div>
              <div className="mt-5 grid gap-3 sm:grid-cols-2 md:grid-cols-1 xl:grid-cols-2">
                {routeHighlights.map((route) => (
                  <ImageRouteCard key={route.title} route={route} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="page py-12">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs font-extrabold uppercase tracking-[0.24em] text-brand-700">Dịch vụ</p>
            <h2 className="section-title mt-2">Chọn đúng nhu cầu</h2>
            <p className="muted mt-2">Mỗi dịch vụ có form riêng để lấy đúng thông tin điều phối và báo giá.</p>
          </div>
          <Link className="btn-secondary" to="/dat-xe">
            Mở form đặt xe
          </Link>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          {services.map((s) => (
            <Link key={s.href} to={s.href} className="card card-hover group min-h-[170px]">
              <div className="grid h-12 w-12 place-items-center rounded-2xl bg-brand-50 text-brand-700 transition group-hover:bg-brand-600 group-hover:text-white">
                <s.icon size={27} />
              </div>
              <h3 className="mt-4 text-lg font-extrabold">{s.title}</h3>
              <p className="mt-2 text-sm leading-6 text-slate-600">{s.desc}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="bg-white">
        <div className="page grid gap-4 py-12 md:grid-cols-3">
          {[
            ["1. Gửi yêu cầu", "Khách chọn tuyến, ngày giờ dương lịch, số người/hàng. Hệ thống hiện giá tạm tính ngay."],
            ["2. Báo giá & xác nhận", "Nhân viên gọi/Zalo xác nhận lại điểm đón, điểm trả, giá và lịch chạy."],
            ["3. Điều phối chuyến", "Gom khách, gán tài xế, theo dõi ghế trống và công nợ rõ ràng."],
          ].map(([title, desc]) => (
            <div className="card card-hover" key={title}>
              <div className="grid h-12 w-12 place-items-center rounded-2xl bg-orange-50 text-orange-600">
                <ClipboardCheck size={25} />
              </div>
              <h3 className="mt-4 text-lg font-extrabold">{title}</h3>
              <p className="mt-2 text-sm leading-6 text-slate-600">{desc}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
