import { useMemo } from 'react';
import { formatDisplayDate, formatDisplayDateTime } from '../../lib/datetime';

const pad = (n: number) => String(n).padStart(2, '0');

type DateParts = { year: number; month: number; day: number };
type DateTimeParts = DateParts & { hour: number; minute: number };

function parseDateValue(value?: string): DateParts {
  const now = new Date();
  const [y, m, d] = (value || '').split('-').map((x) => Number(x));
  return {
    year: Number.isFinite(y) && y > 0 ? y : now.getFullYear(),
    month: Number.isFinite(m) && m >= 1 && m <= 12 ? m : now.getMonth() + 1,
    day: Number.isFinite(d) && d >= 1 && d <= 31 ? d : now.getDate(),
  };
}

function parseDateTimeValue(value?: string): DateTimeParts {
  const [datePart, timePart] = (value || '').split('T');
  const date = parseDateValue(datePart);
  const [h, min] = (timePart || '').split(':').map((x) => Number(x));
  return {
    ...date,
    hour: Number.isFinite(h) && h >= 0 && h <= 23 ? h : 6,
    minute: Number.isFinite(min) && min >= 0 && min <= 59 ? min : 0,
  };
}

function daysInMonth(year: number, month: number) {
  return new Date(year, month, 0).getDate();
}

function clampDay(parts: DateParts) {
  return Math.min(parts.day, daysInMonth(parts.year, parts.month));
}

function toDateValue(parts: DateParts) {
  return `${parts.year}-${pad(parts.month)}-${pad(clampDay(parts))}`;
}

function toDateTimeValue(parts: DateTimeParts) {
  return `${toDateValue(parts)}T${pad(parts.hour)}:${pad(parts.minute)}`;
}

function yearOptions(minYear?: number, maxYear?: number) {
  const nowYear = new Date().getFullYear();
  const start = minYear ?? nowYear - 1;
  const end = maxYear ?? nowYear + 3;
  const years: number[] = [];
  for (let y = start; y <= end; y += 1) years.push(y);
  return years;
}

type GregorianDateInputProps = {
  value?: string;
  onChange: (value: string) => void;
  minYear?: number;
  maxYear?: number;
  required?: boolean;
  className?: string;
};

export function GregorianDateInput({ value, onChange, minYear, maxYear, className = '' }: GregorianDateInputProps) {
  const parts = parseDateValue(value);
  const years = useMemo(() => yearOptions(minYear, maxYear), [minYear, maxYear]);
  const maxDay = daysInMonth(parts.year, parts.month);

  const update = (patch: Partial<DateParts>) => {
    const next = { ...parts, ...patch };
    onChange(toDateValue(next));
  };

  return (
    <div className={className}>
      <div className="grid grid-cols-3 gap-2">
        <select className="input" aria-label="Ngày dương lịch" value={parts.day} onChange={(e) => update({ day: Number(e.target.value) })}>
          {Array.from({ length: maxDay }, (_, i) => i + 1).map((d) => <option key={d} value={d}>Ngày {pad(d)}</option>)}
        </select>
        <select className="input" aria-label="Tháng dương lịch" value={parts.month} onChange={(e) => update({ month: Number(e.target.value) })}>
          {Array.from({ length: 12 }, (_, i) => i + 1).map((m) => <option key={m} value={m}>Tháng {pad(m)}</option>)}
        </select>
        <select className="input" aria-label="Năm dương lịch" value={parts.year} onChange={(e) => update({ year: Number(e.target.value) })}>
          {years.map((y) => <option key={y} value={y}>Năm {y}</option>)}
        </select>
      </div>
      <span className="mt-1 block text-xs font-semibold text-brand-700">Dương lịch: {formatDisplayDate(toDateValue(parts))}</span>
    </div>
  );
}

type GregorianDateTimeInputProps = {
  value?: string;
  onChange: (value: string) => void;
  minYear?: number;
  maxYear?: number;
  className?: string;
};

export function GregorianDateTimeInput({ value, onChange, minYear, maxYear, className = '' }: GregorianDateTimeInputProps) {
  const parts = parseDateTimeValue(value);
  const years = useMemo(() => yearOptions(minYear, maxYear), [minYear, maxYear]);
  const maxDay = daysInMonth(parts.year, parts.month);

  const update = (patch: Partial<DateTimeParts>) => {
    const next = { ...parts, ...patch };
    onChange(toDateTimeValue(next));
  };

  return (
    <div className={className}>
      <div className="grid grid-cols-3 gap-2">
        <select className="input" aria-label="Ngày dương lịch" value={parts.day} onChange={(e) => update({ day: Number(e.target.value) })}>
          {Array.from({ length: maxDay }, (_, i) => i + 1).map((d) => <option key={d} value={d}>Ngày {pad(d)}</option>)}
        </select>
        <select className="input" aria-label="Tháng dương lịch" value={parts.month} onChange={(e) => update({ month: Number(e.target.value) })}>
          {Array.from({ length: 12 }, (_, i) => i + 1).map((m) => <option key={m} value={m}>Tháng {pad(m)}</option>)}
        </select>
        <select className="input" aria-label="Năm dương lịch" value={parts.year} onChange={(e) => update({ year: Number(e.target.value) })}>
          {years.map((y) => <option key={y} value={y}>Năm {y}</option>)}
        </select>
      </div>
      <div className="mt-2 grid grid-cols-2 gap-2">
        <select className="input" aria-label="Giờ đi" value={parts.hour} onChange={(e) => update({ hour: Number(e.target.value) })}>
          {Array.from({ length: 24 }, (_, i) => i).map((h) => <option key={h} value={h}>{pad(h)} giờ</option>)}
        </select>
        <select className="input" aria-label="Phút đi" value={parts.minute} onChange={(e) => update({ minute: Number(e.target.value) })}>
          {[0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55].map((m) => <option key={m} value={m}>{pad(m)} phút</option>)}
        </select>
      </div>
      <span className="mt-1 block text-xs font-semibold text-brand-700">Dương lịch: {formatDisplayDateTime(toDateTimeValue(parts))}</span>
    </div>
  );
}
