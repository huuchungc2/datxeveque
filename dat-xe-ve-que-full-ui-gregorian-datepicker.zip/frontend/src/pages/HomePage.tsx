import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { ArrowRight, Box, Car, CheckCircle2, ClipboardCheck, MapPinned, ShieldCheck, ShoppingBasket, Users, UserPlus } from "lucide-react";

import { coreBookableServices } from "../routes/bookableServices";
import { RouteCard } from "../components/ui/DesignKit";

const serviceIcons: Record<string, typeof Car> = {
  SHARED_RIDE: Car,
  PRIVATE_RIDE: Car,
  CARGO: Box,
  MARKET: ShoppingBasket,
  CONTRACT: Users,
};

const serviceDesc: Record<string, string> = {
  SHARED_RIDE: "Gom khách theo tuyến, giá theo người",
  PRIVATE_RIDE: "Xe riêng 4–7–16 chỗ, giá theo chuyến",
  CARGO: "Nhận hàng 2 chiều, giao tận nơi",
  MARKET: "Mua đồ quê, đóng gói, gửi lên phố",
  CONTRACT: "Theo lịch trình, báo giá riêng",
};

const services = coreBookableServices.map((s) => ({
  title: s.menuLabel,
  desc: serviceDesc[s.type] || s.title,
  icon: serviceIcons[s.type] || Car,
  href: s.path,
}));

export default function HomePage() {
  return (
    <>
      <Helmet>
        <title>Đặt Xe Về Quê | Sài Gòn ⇄ Đức Linh, Tánh Linh</title>
        <meta name="description" content="Đặt xe Sài Gòn đi Đức Linh, Tánh Linh. Xe ghép, bao xe, gửi hàng, đi chợ quê, thuê xe hợp đồng." />
      </Helmet>

      <section className="relative overflow-hidden bg-slate-950 text-white">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_15%_15%,rgba(20,184,166,.42),transparent_32%),radial-gradient(circle_at_85%_20%,rgba(249,115,22,.24),transparent_28%)]" />
        <div className="relative mx-auto grid max-w-7xl gap-10 px-4 py-12 md:grid-cols-[1.1fr_.9fr] md:px-6 md:py-20">
          <div className="flex flex-col justify-center">
            <img src="/brand/logo-dat-xe-ve-que-header.webp" alt="Đặt Xe Về Quê" className="mb-7 h-14 w-fit rounded-2xl bg-white/95 px-4 py-2 object-contain shadow-sm" />
            <span className="mb-4 inline-flex w-fit items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-2 text-sm font-bold text-teal-50 backdrop-blur">
              <ShieldCheck size={17} /> Dịch vụ vận chuyển quê nhà chuyên nghiệp
            </span>
            <h1 className="max-w-3xl text-balance text-4xl font-extrabold leading-tight tracking-tight md:text-6xl">
              Đặt xe về quê rõ giá, rõ chuyến, có người xác nhận
            </h1>
            <p className="mt-5 max-w-2xl text-lg leading-8 text-slate-200">
              Xe ghép, bao xe, gửi hàng, đi chợ quê và thuê xe hợp đồng cho tuyến Sài Gòn ⇄ Đức Linh, Tánh Linh. Đặt nhanh, điều phối minh bạch, tài xế xác nhận trước khi chạy.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link className="btn-primary" to="/dat-xe">Đặt xe ngay <ArrowRight size={18} /></Link>
              <Link className="btn-ghost border-white/20 bg-white/10 text-white hover:bg-white/15" to="/dang-ky?loai=tai-xe"><UserPlus size={18} /> Đăng ký tài xế</Link>
            </div>
            <div className="mt-8 grid gap-3 text-sm text-slate-200 sm:grid-cols-3">
              {[
                "Giá tạm tính trước khi gửi đơn",
                "Gọi/Zalo xác nhận lịch và điểm đón",
                "Theo dõi đơn, chuyến và công nợ rõ ràng",
              ].map((x) => <div key={x} className="flex items-start gap-2"><CheckCircle2 className="mt-0.5 text-teal-300" size={17} />{x}</div>)}
            </div>
          </div>

          <div className="panel border-white/10 bg-white/95 p-5 text-slate-900 shadow-2xl">
            <div className="rounded-[1.75rem] bg-gradient-to-br from-brand-50 to-orange-50 p-6">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-sm font-bold uppercase tracking-wide text-brand-700">Tuyến nổi bật</p>
                  <h2 className="mt-1 text-2xl font-extrabold">Chọn tuyến để đặt ngay</h2>
                </div>
                <MapPinned className="text-brand-700" size={42} />
              </div>
              <div className="mt-5 grid gap-3">
                <RouteCard title="Sài Gòn → Đức Linh" subtitle="Xe ghép / bao xe / gửi hàng" href="/xe-sai-gon-di-duc-linh" />
                <RouteCard title="Sài Gòn → Tánh Linh" subtitle="Đặt lịch trước, có xác nhận" href="/xe-sai-gon-di-tanh-linh" />
                <RouteCard title="Đức Linh → Sài Gòn" subtitle="Chuyến chiều về trong ngày" href="/xe-duc-linh-di-sai-gon" />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="page py-12">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs font-extrabold uppercase tracking-[0.24em] text-brand-700">Dịch vụ</p>
            <h2 className="section-title mt-2">Chọn đúng nhu cầu</h2>
            <p className="muted mt-2">Mỗi dịch vụ có form riêng để lấy đúng thông tin điều phối và báo giá.</p>
          </div>
          <Link className="btn-secondary" to="/dat-xe">Mở form đặt xe</Link>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          {services.map((s) => (
            <Link key={s.href} to={s.href} className="card card-hover group min-h-[170px]">
              <div className="grid h-12 w-12 place-items-center rounded-2xl bg-brand-50 text-brand-700 transition group-hover:bg-brand-600 group-hover:text-white"><s.icon size={27} /></div>
              <h3 className="mt-4 text-lg font-extrabold">{s.title}</h3>
              <p className="mt-2 text-sm leading-6 text-slate-600">{s.desc}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="bg-white">
        <div className="page grid gap-4 py-12 md:grid-cols-3">
          {[
            ["1. Gửi yêu cầu", "Khách chọn tuyến, ngày giờ, số người/hàng. Hệ thống hiện giá tạm tính ngay."],
            ["2. Báo giá & xác nhận", "Nhân viên gọi/Zalo xác nhận lại điểm đón, điểm trả, giá và lịch chạy."],
            ["3. Điều phối chuyến", "Gom khách, gán tài xế, theo dõi ghế trống và công nợ rõ ràng."],
          ].map(([title, desc]) => (
            <div className="card card-hover" key={title}>
              <div className="grid h-12 w-12 place-items-center rounded-2xl bg-orange-50 text-orange-600"><ClipboardCheck size={25} /></div>
              <h3 className="mt-4 text-lg font-extrabold">{title}</h3>
              <p className="mt-2 text-sm leading-6 text-slate-600">{desc}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
