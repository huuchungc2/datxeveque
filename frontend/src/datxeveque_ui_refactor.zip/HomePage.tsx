import { useState, useEffect } from "react";
import { Helmet } from "react-helmet-async";
import { useNavigate } from "react-router-dom";
import { Car, Box, ShoppingBasket, Users, MapPin, ArrowRightLeft, Calendar } from "lucide-react";
import { api, unwrapList } from "../lib/api";
import { coreBookableServices } from "../routes/bookableServices";

const serviceIcons: Record<string, typeof Car> = {
  SHARED_RIDE: Car,
  PRIVATE_RIDE: Car,
  CARGO: Box,
  MARKET: ShoppingBasket,
  CONTRACT: Users,
};

const serviceDesc: Record<string, string> = {
  SHARED_RIDE: "Gom khách theo tuyến, giá tiết kiệm",
  PRIVATE_RIDE: "Xe riêng 4–7–16 chỗ, chủ động hành trình",
  CARGO: "Nhận hàng 2 chiều, giao tận tay",
  MARKET: "Mua đồ quê, đóng gói gửi lên phố",
  CONTRACT: "Thuê xe du lịch, hợp đồng riêng",
};

export default function HomePage() {
  const navigate = useNavigate();
  const [routes, setRoutes] = useState<any[]>([]);
  
  const [searchForm, setSearchForm] = useState({
    routeId: "",
    type: "SHARED_RIDE",
  });

  useEffect(() => {
    api.get("/public/routes").then((res) => {
      setRoutes(unwrapList(res.data));
    }).catch(() => setRoutes([]));
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const selectedService = coreBookableServices.find(s => s.type === searchForm.type);
    const basePath = selectedService ? selectedService.path : "/dat-xe/xe-ghep";
    
    if (searchForm.routeId) {
      navigate(`${basePath}?routeId=${searchForm.routeId}`);
    } else {
      navigate(basePath);
    }
  };

  return (
    <>
      <Helmet>
        <title>Đặt Xe Về Quê | Hệ Thống Đặt Xe Đường Dài Thông Minh</title>
        <meta name="description" content="Đặt xe Sài Gòn đi Đức Linh, Tánh Linh và ngược lại. Xe ghép, bao xe, gửi hàng nhanh chóng." />
      </Helmet>

      {/* 1. HERO SECTION & FORM TÌM KIẾM NHANH */}
      <section className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-brand-950 to-slate-900 py-12 text-white md:py-20">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(20,184,166,0.15),transparent_40%)]" />
        
        <div className="mx-auto max-w-4xl px-4 text-center">
          <span className="inline-block rounded-full bg-brand-500/10 px-4 py-1.5 text-xs font-bold text-brand-400 backdrop-blur-md">
            🚀 Giải pháp về quê an toàn & tiết kiệm
          </span>
          <h1 className="mt-4 text-3xl font-extrabold tracking-tight sm:text-5xl">
            Đặt Xe Về Quê Nhanh Chóng
          </h1>
          <p className="mx-auto mt-3 max-w-xl text-sm text-slate-300 sm:text-base">
            Hỗ trợ xe ghép tiện chuyến, bao xe riêng và ký gửi hàng hóa hai chiều. Nhận xe chạy ngay sau khi xác nhận.
          </p>

          <form onSubmit={handleSearchSubmit} className="mt-10 rounded-2xl border border-slate-800 bg-slate-900/80 p-4 shadow-2xl backdrop-blur-lg sm:p-5 text-left text-ink-900 grid gap-4 md:grid-cols-3">
            <div className="md:col-span-3 flex flex-wrap gap-1.5 p-1 bg-slate-950 rounded-xl">
              {coreBookableServices.map((s) => (
                <button
                  key={s.type}
                  type="button"
                  onClick={() => setSearchForm({ ...searchForm, type: s.type })}
                  className={`flex-1 min-w-[100px] text-center py-2 px-3 rounded-lg text-xs font-bold transition-all ${
                    searchForm.type === s.type
                      ? "bg-cta-500 text-white shadow-md"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  {s.menuLabel}
                </button>
              ))}
            </div>

            <div className="relative">
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <MapPin size={14} className="text-brand-400" /> Tuyến đường hành trình
              </label>
              <select
                value={searchForm.routeId}
                onChange={(e) => setSearchForm({ ...searchForm, routeId: e.target.value })}
                className="w-full h-12 px-3 bg-white border border-slate-200 rounded-xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-brand-500"
              >
                <option value="">-- Chọn tuyến đường đi --</option>
                {routes.map((r) => (
                  <option key={r.id} value={r.id}>{r.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                <Calendar size={14} className="text-brand-400" /> Ngày đi dự kiến
              </label>
              <div className="w-full h-12 px-3 bg-white border border-slate-200 rounded-xl flex items-center text-sm font-medium text-slate-500">
                Hẹn lịch ở bước tiếp theo
              </div>
            </div>

            <div className="flex items-end">
              <button type="submit" className="w-full h-12 btn-primary flex justify-center items-center gap-2 rounded-xl text-base font-bold shadow-lg">
                Tìm chuyến xe <ArrowRightLeft size={18} />
              </button>
            </div>
          </form>
        </div>
      </section>

      {/* 2. KHU VỰC CHỌN DỊCH VỤ CHI TIẾT */}
      <section className="mx-auto max-w-7xl px-4 py-12">
        <div className="mb-8">
          <h2 className="text-2xl font-extrabold sm:text-3xl">Tất cả dịch vụ</h2>
          <p className="mt-1.5 text-sm text-slate-600">Chọn đúng loại hình bạn cần để tối ưu chi phí di chuyển.</p>
        </div>
        
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          {coreBookableServices.map((s) => {
            const Icon = serviceIcons[s.type] || Car;
            return (
              <button
                key={s.path}
                onClick={() => navigate(searchForm.routeId ? `${s.path}?routeId=${searchForm.routeId}` : s.path)}
                className="card text-left transition-all hover:-translate-y-1 hover:shadow-lg hover:border-brand-300 group"
              >
                <div className="inline-flex p-3 rounded-2xl bg-brand-50 text-brand-700 mb-4 group-hover:bg-brand-700 group-hover:text-white transition-all">
                  <Icon size={24} />
                </div>
                <h3 className="text-lg font-bold text-slate-900 group-hover:text-brand-700">{s.menuLabel}</h3>
                <p className="mt-2 text-xs leading-5 text-slate-600">{serviceDesc[s.type] || s.title}</p>
              </button>
            );
          })}
        </div>
      </section>

      {/* 3. QUY TRÌNH ĐẶT XE ĐƠN GIẢN */}
      <section className="bg-white border-y border-slate-100">
        <div className="mx-auto grid max-w-7xl gap-6 px-4 py-14 md:grid-cols-3">
          <div className="flex gap-4 items-start">
            <div className="w-10 h-10 rounded-full bg-cta-50 text-cta-600 font-black flex items-center justify-center shrink-0">1</div>
            <div>
              <h3 className="font-bold text-slate-900 text-lg">Gửi thông tin</h3>
              <p className="text-sm text-slate-600 mt-1">Chọn lộ trình, ngày giờ và số chỗ mong muốn cực nhanh gọn.</p>
            </div>
          </div>
          <div className="flex gap-4 items-start">
            <div className="w-10 h-10 rounded-full bg-cta-50 text-cta-600 font-black flex items-center justify-center shrink-0">2</div>
            <div>
              <h3 className="font-bold text-slate-900 text-lg">Tổng đài gọi lại</h3>
              <p className="text-sm text-slate-600 mt-1">Nhân viên sẽ kiểm tra xe trống và gọi điện xác nhận điểm đón trả tận nơi.</p>
            </div>
          </div>
          <div className="flex gap-4 items-start">
            <div className="w-10 h-10 rounded-full bg-cta-50 text-cta-600 font-black flex items-center justify-center shrink-0">3</div>
            <div>
              <h3 className="font-bold text-slate-900 text-lg">Lên xe về quê</h3>
              <p className="text-sm text-slate-600 mt-1">Tài xế đón đúng hẹn, đi an toàn. Hoàn thành chuyến đi mới trả tiền.</p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
