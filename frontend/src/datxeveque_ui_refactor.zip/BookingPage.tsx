import { useEffect, useMemo, useState } from "react";
import { Helmet } from "react-helmet-async";
import { useSearchParams, useNavigate } from "react-router-dom";
import { 
  ArrowLeft, ArrowRight, CalendarClock, CheckCircle2, MapPin, 
  ReceiptText, Route as RouteIcon, ShieldCheck, Users, Box 
} from "lucide-react";
import { api, formatMoney, unwrapList } from "../lib/api";
import { defaultDepartureLocal } from "../lib/datetime";
import { normalizeVnPhone, PHONE_INVALID_MESSAGE, phoneInputProps, sanitizePhoneInput } from "../lib/phone";
import { allBookingServiceOptions, ROUTE_REQUIRED_SERVICE_TYPES } from "../routes/bookableServices";
import { usesPassengerCount } from "../lib/bookingSeats";
import { serviceTypeLabel } from "../lib/serviceTypes";
import { useSiteSettings } from "../lib/useSiteSettings";
import { GregorianDateTimeInput } from "../components/ui/GregorianDateInputs";

function canEstimatePrice(form: { type?: string; routeId?: string }) {
  if (!form.type) return false;
  if (ROUTE_REQUIRED_SERVICE_TYPES.has(form.type) && !form.routeId) return false;
  return true;
}

function priceHint(form: { type?: string; routeId?: string }) {
  if (!form.type) return "Chọn loại dịch vụ để xem giá tạm tính";
  if (ROUTE_REQUIRED_SERVICE_TYPES.has(form.type) && !form.routeId) return "Chọn tuyến để xem giá tạm tính";
  return "";
}

type Props = { type?: string; title?: string; defaultRouteId?: number };

export default function BookingPage({ type: initType, title: propTitle, defaultRouteId }: Props) {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { settings } = useSiteSettings();

  const [step, setStep] = useState(1);

  const queryRouteId = searchParams.get("routeId");
  const initialRouteId = defaultRouteId || (queryRouteId ? Number(queryRouteId) : "");

  const [routes, setRoutes] = useState<any[]>([]);
  const [form, setForm] = useState({
    type: initType || "SHARED_RIDE",
    routeId: initialRouteId,
    customerName: "",
    customerPhone: "",
    scheduledAt: defaultDepartureLocal(),
    pickupAddress: "",
    dropoffAddress: "",
    passengerCount: 1,
    weightKg: 5,
    note: "",
    cargoDescription: "",
    vehicleSizeRequirement: "Xe 4 chỗ",
  });

  const [loading, setLoading] = useState(false);
  const [successData, setSuccessData] = useState<any>(null);
  const [error, setError] = useState("");
  const [price, setPrice] = useState<any>(null);

  useEffect(() => {
    api.get("/public/routes").then((res) => setRoutes(unwrapList(res.data))).catch(() => {});
  }, []);

  const selectedRoute = useMemo(() => routes.find((r) => Number(r.id) === Number(form.routeId)), [routes, form.routeId]);

  useEffect(() => {
    if (!canEstimatePrice(form)) {
      setPrice(null);
      return;
    }
    const delay = setTimeout(() => {
      api.post("/public/bookings/estimate-price", form)
        .then((r) => setPrice(r.data))
        .catch(() => setPrice(null));
    }, 300);
    return () => clearTimeout(delay);
  }, [form]);

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, customerPhone: sanitizePhoneInput(e.target.value) });
  };

  const validateStep = () => {
    setError("");
    if (step === 1) {
      if (ROUTE_REQUIRED_SERVICE_TYPES.has(form.type) && !form.routeId) {
        setError("Vui lòng chọn Tuyến đường hành trình.");
        return false;
      }
      if (!form.scheduledAt) {
        setError("Vui lòng chọn thời gian xuất phát.");
        return false;
      }
    }
    if (step === 2) {
      if (!form.pickupAddress.trim()) {
        setError("Vui lòng nhập địa chỉ đón tận nơi.");
        return false;
      }
      if (!form.dropoffAddress.trim()) {
        setError("Vui lòng nhập địa chỉ trả tận nơi.");
        return false;
      }
    }
    return true;
  };

  const nextStep = () => {
    if (validateStep()) setStep((prev) => prev + 1);
  };

  const prevStep = () => {
    setError("");
    setStep((prev) => prev - 1);
  };

  const submitBooking = async () => {
    setError("");
    const p = normalizeVnPhone(form.customerPhone);
    if (!p) {
      setError(PHONE_INVALID_MESSAGE);
      return;
    }
    if (!form.customerName.trim()) {
      setError("Vui lòng nhập họ và tên người đi xe.");
      return;
    }

    setLoading(true);
    try {
      const payload = { ...form, customerPhone: p };
      const res = await api.post("/public/bookings", payload);
      setSuccessData(res.data);
    } catch (err: any) {
      setError(err.response?.data?.message || "Hệ thống bận, vui lòng thử lại sau hoặc gọi hotline.");
    } finaly {
      setLoading(false);
    }
  };

  if (successData) {
    return (
      <div className="page max-w-xl py-10 text-center">
        <Helmet><title>Đặt xe thành công | {settings.brand_name}</title></Helmet>
        <div className="panel flex flex-col items-center p-8 shadow-xl">
          <div className="rounded-full bg-emerald-50 p-4 text-emerald-600 mb-4 animate-bounce">
            <CheckCircle2 size={48} />
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900">Đăng Ký Đặt Xe Thành Công!</h1>
          <p className="mt-3 text-sm text-slate-600 leading-6">
            Mã đơn của bạn là <b className="text-lg text-brand-700 font-mono tracking-wider bg-slate-100 px-2 py-0.5 rounded">{successData.code}</b>.<br />
            Nhân viên điều phối sẽ kiểm tra lịch xe trống và gọi lại cho bạn qua số máy <b className="text-slate-900">{form.customerPhone}</b> trong ít phút để xác nhận giá và giờ đón cụ thể.
          </p>
          <div className="mt-6 w-full border-t pt-4 text-left space-y-2 text-xs text-slate-500">
            <p>• Loại dịch vụ: <b>{serviceTypeLabel[form.type]}</b></p>
            <p>• Hành trình: <b>{selectedRoute?.name || "Đang xử lý"}</b></p>
            <p>• Giá tạm tính: <b className="text-sm text-cta-500">{price ? formatMoney(price.estimatedTotal) : "Chờ tổng đài xác nhận"}</b></p>
          </div>
          <button onClick={() => navigate("/")} className="btn-ghost mt-8 w-full rounded-xl py-3 font-bold">
            Quay lại Trang Chủ
          </button>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>{propTitle || "Đặt xe trực tuyến"} | {settings.brand_name}</title>
      </Helmet>

      <div className="page max-w-2xl py-6 pb-24 md:pb-8">
        
        {/* PROGRESS BAR */}
        <div className="mb-8 flex items-center justify-between px-2 text-xs font-bold uppercase tracking-wider text-slate-400">
          <div className={`flex items-center gap-1.5 ${step >= 1 ? "text-brand-700" : ""}`}>
            <span className={`w-5 h-5 rounded-full flex items-center justify-center border text-[10px] ${step >= 1 ? "bg-brand-700 border-brand-700 text-white" : "border-slate-300"}`}>1</span>
            Hành trình
          </div>
          <div className="h-[2px] flex-1 bg-slate-200 mx-3" />
          <div className={`flex items-center gap-1.5 ${step >= 2 ? "text-brand-700" : ""}`}>
            <span className={`w-5 h-5 rounded-full flex items-center justify-center border text-[10px] ${step >= 2 ? "bg-brand-700 border-brand-700 text-white" : "border-slate-300"}`}>2</span>
            Đón trả
          </div>
          <div className="h-[2px] flex-1 bg-slate-200 mx-3" />
          <div className={`flex items-center gap-1.5 ${step >= 3 ? "text-brand-700" : ""}`}>
            <span className={`w-5 h-5 rounded-full flex items-center justify-center border text-[10px] ${step >= 3 ? "bg-brand-700 border-brand-700 text-white" : "border-slate-300"}`}>3</span>
            Liên hệ
          </div>
        </div>

        {error && <div className="mb-4 rounded-xl bg-red-50 border border-red-200 p-3.5 text-sm font-medium text-red-700">{error}</div>}

        <div className="panel shadow-xl p-5 sm:p-6">
          <h2 className="text-xl font-extrabold text-slate-900 mb-5 flex items-center gap-2">
            <ReceiptText className="text-brand-700" size={20} />
            {propTitle ? `Đặt vé: ${propTitle}` : "Đăng ký thông tin hành trình"}
          </h2>

          {/* STEP 1 */}
          {step === 1 && (
            <div className="space-y-5">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide mb-2">Loại hình dịch vụ</label>
                <div className="grid grid-cols-2 gap-2">
                  {allBookingServiceOptions.map((opt) => (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => setForm({ ...form, type: opt.value })}
                      className={`p-3 rounded-xl border text-left transition-all flex flex-col justify-between h-20 ${
                        form.type === opt.value
                          ? "border-brand-600 bg-brand-50/50 ring-1 ring-brand-600 text-brand-900"
                          : "border-slate-200 hover:border-slate-300 bg-white"
                      }`}
                    >
                      <span className="font-bold text-sm">{opt.label}</span>
                      <span className="text-[10px] text-slate-500 font-normal leading-normal">
                        {opt.value === "SHARED_RIDE" ? "Tính theo số người đi" : "Thuê trọn gói xe riêng"}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {ROUTE_REQUIRED_SERVICE_TYPES.has(form.type) && (
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide mb-2">Tuyến đường hành trình</label>
                  <select
                    value={form.routeId}
                    onChange={(e) => setForm({ ...form, routeId: e.target.value })}
                    className="w-full h-12 px-3 bg-white border border-slate-200 rounded-xl text-sm font-semibold text-ink-900 focus:ring-2 focus:ring-brand-500 focus:outline-none"
                  >
                    <option value="">-- Click chọn tuyến đường của bạn --</option>
                    {routes.map((r) => (
                      <option key={r.id} value={r.id}>{r.name}</option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide mb-2">Thời gian xuất phát dự kiến</label>
                <GregorianDateTimeInput
                  value={form.scheduledAt}
                  onChange={(val) => setForm({ ...form, scheduledAt: val })}
                />
              </div>

              {usesPassengerCount(form.type) ? (
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide mb-2 flex justify-between">
                    <span>Số lượng hành khách</span>
                    <span className="text-brand-700 font-mono font-bold text-sm">{form.passengerCount} người</span>
                  </label>
                  <input
                    type="range" min={1} max={10}
                    value={form.passengerCount}
                    onChange={(e) => setForm({ ...form, passengerCount: Number(e.target.value) })}
                    className="w-full accent-brand-700 h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer"
                  />
                </div>
              ) : form.type === "CARGO" ? (
                <div className="grid gap-4 sm:grid-cols-2">
                  <label className="block text-sm font-bold">Cân nặng tạm tính (kg)
                    <input type="number" min={1} className="input mt-2" value={form.weightKg} onChange={(e) => setForm({ ...form, weightKg: Number(e.target.value) })} />
                  </label>
                  <label className="block text-sm font-bold">Mô tả hàng hóa
                    <input className="input mt-2" value={form.cargoDescription} onChange={(e) => setForm({ ...form, cargoDescription: e.target.value })} placeholder="Ví dụ: Thùng xốp đồ ăn, xe máy..." />
                  </label>
                </div>
              ) : form.type === "PRIVATE_RIDE" ? (
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide mb-2">Kích thước xe yêu cầu</label>
                  <select className="w-full h-12 px-3 bg-white border border-slate-200 rounded-xl text-sm font-semibold focus:ring-2 focus:ring-brand-500 focus:outline-none" value={form.vehicleSizeRequirement} onChange={(e) => setForm({ ...form, vehicleSizeRequirement: e.target.value })}>
                    <option>Xe 4 chỗ</option>
                    <option>Xe 7 chỗ</option>
                    <option>Xe 16 chỗ</option>
                    <option>Xe 29 chỗ</option>
                  </select>
                </div>
              ) : null}

              <button type="button" onClick={nextStep} className="w-full h-12 btn-primary flex justify-center items-center gap-2 rounded-xl text-sm font-bold shadow-md mt-6">
                Tiếp tục chọn điểm đón <ArrowRight size={16} />
              </button>
            </div>
          )}

          {/* STEP 2 */}
          {step === 2 && (
            <div className="space-y-5">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide mb-1.5 flex items-center gap-1">
                  <MapPin size={14} className="text-emerald-600" /> Địa chỉ đón khách tận nơi
                </label>
                <input 
                  className="input h-12" 
                  value={form.pickupAddress} 
                  onChange={(e) => setForm({ ...form, pickupAddress: e.target.value })} 
                  placeholder="Nhập số nhà, tên đường, thôn/xóm..." 
                />
                <span className="text-[11px] text-slate-400 mt-1 block">Tài xế sẽ đón bạn chính xác tại điểm này.</span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wide mb-1.5 flex items-center gap-1">
                  <MapPin size={14} className="text-red-500" /> Địa chỉ trả khách tận nơi
                </label>
                <input 
                  className="input h-12" 
                  value={form.dropoffAddress} 
                  onChange={(e) => setForm({ ...form, dropoffAddress: e.target.value })} 
                  placeholder="Nhập địa chỉ cụ thể nơi bạn muốn xuống xe..." 
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button type="button" onClick={prevStep} className="w-1/3 h-12 btn-ghost flex justify-center items-center gap-2 rounded-xl text-sm font-bold">
                  <ArrowLeft size={16} /> Quay lại
                </button>
                <button type="button" onClick={nextStep} className="w-2/3 h-12 btn-primary flex justify-center items-center gap-2 rounded-xl text-sm font-bold shadow-md">
                  Nhập thông tin liên hệ <ArrowRight size={16} />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3 */}
          {step === 3 && (
            <div className="space-y-5">
              <div className="grid gap-4 sm:grid-cols-2">
                <label className="block text-sm font-bold text-slate-900">Họ và tên người đi xe
                  <input className="input h-12 mt-2" value={form.customerName} onChange={(e) => setForm({ ...form, customerName: e.target.value })} placeholder="Nguyễn Văn A" />
                </label>
                <label className="block text-sm font-bold text-slate-900">Số điện thoại nhận vé
                  <input className="input h-12 mt-2" type="tel" {...phoneInputProps} value={form.customerPhone} onChange={handlePhoneChange} placeholder="0912xxxxxx" />
                </label>
              </div>

              <label className="block text-sm font-bold text-slate-900">Ghi chú bổ sung (nếu có)
                <textarea className="input mt-2 p-3" rows={3} value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} placeholder="Ví dụ: Xe có trẻ em, mang theo nhiều đồ cồng kềnh..." />
              </label>

              <div className="flex gap-3 pt-4">
                <button type="button" onClick={prevStep} className="w-1/3 h-12 btn-ghost flex justify-center items-center gap-2 rounded-xl text-sm font-bold">
                  <ArrowLeft size={16} /> Quay lại
                </button>
                <button type="button" disabled={loading} onClick={submitBooking} className="w-2/3 h-12 btn-primary bg-cta-500 hover:bg-cta-600 flex justify-center items-center gap-2 rounded-xl text-sm font-bold shadow-lg disabled:opacity-50">
                  {loading ? "Đang xử lý đặt vé..." : "Xác nhận đặt xe ngay"}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* REASSURANCE BANNER */}
        <div className="mt-5 rounded-2xl border border-dashed border-slate-200 bg-white p-4 flex items-start gap-3">
          <ShieldCheck className="text-emerald-600 shrink-0 mt-0.5" size={20} />
          <p className="text-xs text-slate-500 leading-normal">
            <b>Cam kết từ hệ thống:</b> Toàn bộ luồng đặt xe không yêu cầu khách hàng phải thanh toán trước. Bạn chỉ thanh toán tiền mặt hoặc chuyển khoản trực tiếp cho tài xế sau khi hoàn thành hành trình về quê an toàn.
          </p>
        </div>

        {/* STICKY BAR */}
        <div className="fixed bottom-0 left-0 right-0 z-50 border-t border-slate-100 bg-white p-4 px-5 flex items-center justify-between shadow-[0_-8px_30px_rgba(0,0,0,0.06)] md:relative md:shadow-none md:border-none md:p-0 md:mt-6">
          <div className="text-left">
            <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider block">Giá vé tạm tính</span>
            <b className="text-xl text-cta-500 font-black">
              {canEstimatePrice(form) && price ? formatMoney(price.estimatedTotal) : "—"}
            </b>
          </div>
          <div className="text-right text-[11px] text-slate-500 font-medium max-w-[180px] leading-tight md:max-w-none">
            {priceHint(form) ? (
              <span className="text-amber-700 font-semibold">{priceHint(form)}</span>
            ) : (
              <span>Đã bao gồm phí đón trả tận nơi theo tuyến</span>
            )}
          </div>
        </div>

      </div>
    </>
  );
}
